#Script written by Brett Korteling of Vive le Monde Mapping - brett@vivelemonde.net (Jan 2012)

# Create centroids for all spatial layers
# Perform spatial joins Cadastre point with Assessment polygon and Assessment point with Cadastre polygon to get
# a full listing of all possible PID to Folio many-to-many relationships
# Perform two spatial joins with Cadastre point, one with planning neighbourhoods and one with census neighbourhoods to
# form the basis for spatial summaries of energy use data at the neighbourhood level
#
# The full sequence to create the PID to Folio many-to-many is
# 1.	Create parcel centroid
# 2.	Run a one-to-many spatial join between this point layer (target feature) and the BC Assessment fabric polygons (join feature)
# 3.	Create an assessment fabric centroid
# 4.	Run a one-to-many spatial join between this point layer (target feature) and the cadastre polygons (join feature)
# 5.	Append the PID and Folio from the table of this join layer with a table from ParcelCentroid/AssessmentPolygon join layer
# 6.	Run a Frequency_analysis on the appended table for PID and Folio to get a unique listing of all the possible relationships

# The reason to need to do the other join based on Assessment points is that BCA sometimes creates little polygon diamonds inside a parcel
# to represent a folio number and if there are more than one of these diamonds, some of the folios will get left out with only steps #1 and#2.
# Steps 5 and 6 occur in the Create tables script which is script #4 in the sequence


import arcpy
from arcpy import env

# Grab parameters from the tool GUI
inFGDBName   = arcpy.GetParameterAsText(0)

WorkingDirectory = inFGDBName
env.Workspace = WorkingDirectory

# Assign names to layers
ParcelFullName = WorkingDirectory + "\\Parcel"
AssessmentFabricFullName = WorkingDirectory + "\\BCAssessment"
PlanningNeighbourhoodFullName = WorkingDirectory + "\\PlanningNeighbourhood"
CensusNeighbourhoodFullName = WorkingDirectory + "\\CensusNeighbourhood"
ParcelCentroidFullName = WorkingDirectory + "\\Parcel_Centroid"
AssessmentFabricCentroidFullName = WorkingDirectory + "\\BCAssessment_Centroid"
ParcelCentroidWithFolioFullName = WorkingDirectory + "\\Parcel_CentroidWithFolio"
AssessmentFabricCentroidWithPIDFullName = WorkingDirectory + "\\BCAssessment_CentroidWithPID"
ParcelCentroidWithFolioAndPlanningFullName = WorkingDirectory + "\\Parcel_CentroidWithFolioPlanning"
ParcelCentroidWithFolioAndPlanningAndCensusFullName = WorkingDirectory + "\\Parcel_CentroidWithFolioPlanningCensus"

if arcpy.Exists(ParcelCentroidFullName):
    arcpy.Delete_management(ParcelCentroidFullName, "Feature Class")
    
if arcpy.Exists(ParcelCentroidWithFolioFullName):
    arcpy.Delete_management(ParcelCentroidWithFolioFullName, "Feature Class")

if arcpy.Exists(AssessmentFabricCentroidFullName):
    arcpy.Delete_management(AssessmentFabricCentroidFullName, "Feature Class")
    
if arcpy.Exists(AssessmentFabricCentroidWithPIDFullName):
    arcpy.Delete_management(AssessmentFabricCentroidWithPIDFullName, "Feature Class")

if arcpy.Exists(ParcelCentroidWithFolioAndPlanningFullName):
    arcpy.Delete_management(ParcelCentroidWithFolioAndPlanningFullName, "Feature Class")

if arcpy.Exists(ParcelCentroidWithFolioAndPlanningAndCensusFullName):
    arcpy.Delete_management(ParcelCentroidWithFolioAndPlanningAndCensusFullName, "Feature Class")

# Fix any problems with the geometry
arcpy.RepairGeometry_management (ParcelFullName, "DELETE_NULL")
arcpy.RepairGeometry_management (AssessmentFabricFullName, "DELETE_NULL")
arcpy.RepairGeometry_management (PlanningNeighbourhoodFullName, "DELETE_NULL")
arcpy.RepairGeometry_management (CensusNeighbourhoodFullName, "DELETE_NULL")

# Process: Feature To Point
arcpy.FeatureToPoint_management(ParcelFullName, ParcelCentroidFullName, "INSIDE")

# Process: Feature To Point
arcpy.FeatureToPoint_management(AssessmentFabricFullName, AssessmentFabricCentroidFullName, "INSIDE")

# Process: Spatial Join
arcpy.SpatialJoin_analysis(ParcelCentroidFullName, AssessmentFabricFullName, ParcelCentroidWithFolioFullName, "JOIN_ONE_TO_MANY", "KEEP_ALL", "TaNDM_Unique \"TaNDM_Unique\" true true false 255 Text 0 0 ,First,#," + ParcelCentroidFullName + ",TaNDM_Unique,-1,-1;TaNDM_Folio \"TaNDM_Folio\" true true false 255 Text 0 0 ,First,#," + AssessmentFabricFullName + ",TaNDM_Folio,-1,-1", "WITHIN", "", "")

# Process: Spatial Join
arcpy.SpatialJoin_analysis(AssessmentFabricCentroidFullName, ParcelFullName, AssessmentFabricCentroidWithPIDFullName, "JOIN_ONE_TO_MANY", "KEEP_ALL", "TaNDM_Unique \"TaNDM_Unique\" true true false 255 Text 0 0 ,First,#," + ParcelCentroidFullName + ",TaNDM_Unique,-1,-1;TaNDM_Folio \"TaNDM_Folio\" true true false 255 Text 0 0 ,First,#," + AssessmentFabricFullName + ",TaNDM_Folio,-1,-1", "WITHIN", "", "")


# Process: Spatial Join
arcpy.SpatialJoin_analysis(ParcelCentroidWithFolioFullName, PlanningNeighbourhoodFullName, ParcelCentroidWithFolioAndPlanningFullName, "JOIN_ONE_TO_ONE", "KEEP_ALL", "TaNDM_Unique \"TaNDM_Unique\" true true false 255 Text 0 0 ,First,#," + ParcelCentroidWithFolioFullName + ",TaNDM_Unique,-1,-1;TaNDM_Folio \"TaNDM_Folio\" true true false 255 Text 0 0 ,First,#," + ParcelCentroidWithFolioFullName + ",TaNDM_Folio,-1,-1;TaNDM_PlanningNeighbourhood \"TaNDM_PlanningNeighbourhood\" true true false 50 Text 0 0 ,First,#," + PlanningNeighbourhoodFullName + ",TaNDM_PlanningNeighbourhood,-1,-1", "WITHIN", "", "")

# Process: Spatial Join
arcpy.SpatialJoin_analysis(ParcelCentroidWithFolioAndPlanningFullName, CensusNeighbourhoodFullName, ParcelCentroidWithFolioAndPlanningAndCensusFullName, "JOIN_ONE_TO_ONE", "KEEP_ALL", "TaNDM_Unique \"TaNDM_Unique\" true true false 255 Text 0 0 ,First,#," + ParcelCentroidWithFolioAndPlanningFullName + ",TaNDM_Unique,-1,-1;TaNDM_Folio \"TaNDM_Folio\" true true false 255 Text 0 0 ,First,#," + ParcelCentroidWithFolioAndPlanningFullName + ",TaNDM_Folio,-1,-1;TaNDM_PlanningNeighbourhood \"TaNDM_PlanningNeighbourhood\" true true false 50 Text 0 0 ,First,#," + ParcelCentroidWithFolioAndPlanningFullName + ",TaNDM_PlanningNeighbourhood,-1,-1;TaNDM_CensusNeighbourhood \"TaNDM_CensusNeighbourhood\" true true false 50 Text 0 0 ,First,#," + CensusNeighbourhoodFullName + ",TaNDM_CensusNeighbourhood,-1,-1", "WITHIN", "", "")


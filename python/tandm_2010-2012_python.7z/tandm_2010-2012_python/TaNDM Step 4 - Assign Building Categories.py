# Script written by Brett Korteling of Vive le Monde Mapping - brett@vivelemonde.net (Jan 2012)
#
# Assign building categories based on Actual Use Code and Manual Class Code lookup tables created by the TaNDM working group

import arcpy
from arcpy import env

# Grab parameters from the tool GUI
inFGDBName   = arcpy.GetParameterAsText(0)

WorkingDirectory = inFGDBName
env.Workspace = WorkingDirectory

# Create names for input tables
BCABIRFullName = WorkingDirectory + "\\BCABuildingInformationReport"

lutActualUseCodeFullName = WorkingDirectory + "\\lutActualUseCodeTable"
lutManualClassCodeFullName = WorkingDirectory + "\\lutManualClassCodeTable"

lutOccupancyFullName = WorkingDirectory + "\\lutOccupancyTable"
lutUnitOfMeasureFullName = WorkingDirectory + "\\lutUnitOfMeasureTable"

# Process: Add Join
arcpy.JoinField_management(BCABIRFullName, "TaNDM_AUC", lutActualUseCodeFullName, "ActualUseCode", ["MajorCategory", "Category", "Sub_category"])
arcpy.JoinField_management(BCABIRFullName, "TaNDM_MCC", lutManualClassCodeFullName, "ManualClassCode", ["MCC_Sub_category"] )
arcpy.AddMessage("Added temporary Manual Class sub categories to BCA Building Information Report...")

arcpy.MakeTableView_management(BCABIRFullName,"BCABIRView")

# Process: Add Join
arcpy.SelectLayerByAttribute_management("BCABIRView", "NEW_SELECTION", "Category = 'Education' and MCC <> ''")
arcpy.CalculateField_management("BCABIRView", "Sub_category", "!MCC_Sub_category!", "PYTHON", "")

arcpy.SelectLayerByAttribute_management("BCABIRView", "NEW_SELECTION", "Category = 'Multi-family' and MCC <> ''")
arcpy.CalculateField_management("BCABIRView", "Sub_category", "!MCC_Sub_category!", "PYTHON", "")

arcpy.SelectLayerByAttribute_management("BCABIRView", "NEW_SELECTION", "Category = 'Office' and TaNDM_FloorArea < 20000")
arcpy.CalculateField_management("BCABIRView", "Sub_category", "'Office - small'", "PYTHON", "")

arcpy.SelectLayerByAttribute_management("BCABIRView", "NEW_SELECTION", "Category = 'Office' and TaNDM_FloorArea >= 20000 and TaNDM_FloorArea < 50000")
arcpy.CalculateField_management("BCABIRView", "Sub_category", "'Office - medium'", "PYTHON", "")

arcpy.SelectLayerByAttribute_management("BCABIRView", "NEW_SELECTION", "Category = 'Office' and TaNDM_FloorArea > 50000")
arcpy.CalculateField_management("BCABIRView", "Sub_category", "'Office - large'", "PYTHON", "")

arcpy.DeleteField_management("BCABIRView", ["MCC_Sub_category"])

arcpy.AddMessage("Refined classification of Education, Multi-family and Office for BCA Building Information Report...")

# Process: Add Join
arcpy.JoinField_management(BCABIRFullName, "Occupancy", lutOccupancyFullName, "Occupancy_lut", ["MajorCategory_occ", "Category_occ", "Sub_category_occ"] )

# add temp field that combines Occupancy and Unit of Measure to facilitate a link with the lutUnitOfMeasure table

targetFeatureClass = "BCABIRView"
defaultNumberValue = "0"
defaultTextValue = "'Unassigned'"

targetFieldName = "Check_Occ_UoM"
arcpy.AddField_management(targetFeatureClass, targetFieldName, "TEXT")

targetFieldName = "TaNDM_Occ_UoM"
arcpy.AddField_management(targetFeatureClass, targetFieldName, "TEXT")
arcpy.SelectLayerByAttribute_management("BCABIRView", "NEW_SELECTION", "Sub_category_occ <> ''")
arcpy.CalculateField_management(targetFeatureClass, targetFieldName, "!Occupancy! + '-' + !UnitOfMeasure!", "PYTHON")
arcpy.CalculateField_management("BCABIRView", "Check_Occ_UoM", "'z'", "PYTHON", "")
arcpy.SelectLayerByAttribute_management("BCABIRView", "SWITCH_SELECTION", "")
arcpy.CalculateField_management(targetFeatureClass, targetFieldName, "'No Occupancy info'", "PYTHON")
arcpy.SelectLayerByAttribute_management("BCABIRView", "CLEAR_SELECTION", "")


arcpy.JoinField_management(BCABIRFullName, "TaNDM_Occ_UoM", lutUnitOfMeasureFullName, "Occ_UoM_lut", ["MajorCategory_uom", "Category_uom", "Sub_category_uom"]  )
arcpy.AddMessage("Added temporary Occupancy and UnitOfMeasure categories to BCA Building Information Report...")

# refine mixed use categorization to specify residential or commercial where Occupancy and Unit of Measure values can help achieve this
# otherwise the mixed use categorization will remain Mixed-use commercial and residential
# so that floor areas are never duplicated or partitioned to define mixed use as commercial or residential
# utilities may be able to separate the commercial and residential energy use based on rate class,
# but this is not necessarily helpful if the building classifications and associated floor area cannot be separated

arcpy.SelectLayerByAttribute_management("BCABIRView", "NEW_SELECTION", "Category = 'Mixed-use commercial and residential' and MajorCategory_occ = 'Residential' and TaNDM_Occ_UoM <> 'No Occupancy info'")
arcpy.CalculateField_management("BCABIRView", "MajorCategory", "'Residential'", "PYTHON", "")
arcpy.CalculateField_management("BCABIRView", "Sub_category", "'Mixed-use residential'", "PYTHON", "")
arcpy.CalculateField_management("BCABIRView", "Check_Occ_UoM", "'y'", "PYTHON", "")
arcpy.SelectLayerByAttribute_management("BCABIRView", "CLEAR_SELECTION", "")

arcpy.SelectLayerByAttribute_management("BCABIRView", "NEW_SELECTION", "Category = 'Mixed-use commercial and residential' and MajorCategory_occ = 'Commercial/Institutional' and TaNDM_Occ_UoM <> 'No Occupancy info'")
arcpy.CalculateField_management("BCABIRView", "MajorCategory", "'Commercial/Institutional'", "PYTHON", "")
arcpy.CalculateField_management("BCABIRView", "Sub_category", "'Mixed-use commercial'", "PYTHON", "")
arcpy.CalculateField_management("BCABIRView", "Check_Occ_UoM", "'x'", "PYTHON", "")
arcpy.SelectLayerByAttribute_management("BCABIRView", "CLEAR_SELECTION", "")

arcpy.SelectLayerByAttribute_management("BCABIRView", "NEW_SELECTION", "MajorCategory_occ <> '' and Category <>  'Mixed-use commercial and residential' and Category_occ <>  '?' and TaNDM_Occ_UoM <> '-' and TaNDM_Occ_UoM <> 'No Occupancy info'")
arcpy.CalculateField_management("BCABIRView", "MajorCategory", "!MajorCategory_occ!", "PYTHON", "")
arcpy.CalculateField_management("BCABIRView", "Category", "!Category_occ!", "PYTHON", "")
arcpy.CalculateField_management("BCABIRView", "Sub_category", "!Sub_category_occ!", "PYTHON", "")
arcpy.CalculateField_management("BCABIRView", "Check_Occ_UoM", "'w'", "PYTHON", "")
arcpy.SelectLayerByAttribute_management("BCABIRView", "CLEAR_SELECTION", "")

arcpy.SelectLayerByAttribute_management("BCABIRView", "NEW_SELECTION", "MajorCategory_uom <> '' and TaNDM_Occ_UoM <> 'No Occupancy info' or TaNDM_Occ_UoM <> '-' and TaNDM_Occ_UoM <> 'No Occupancy info'")
arcpy.CalculateField_management("BCABIRView", "MajorCategory", "!MajorCategory_uom!", "PYTHON", "")
arcpy.CalculateField_management("BCABIRView", "Category", "!Category_uom!", "PYTHON", "")
arcpy.CalculateField_management("BCABIRView", "Sub_category", "!Sub_category_uom!", "PYTHON", "")
arcpy.CalculateField_management("BCABIRView", "Check_Occ_UoM", "'v'", "PYTHON", "")
arcpy.SelectLayerByAttribute_management("BCABIRView", "CLEAR_SELECTION", "")

targetFeatureClass = "BCABIRView"
targetFieldName = "MatchResult"
arcpy.AddField_management(targetFeatureClass, targetFieldName, "TEXT")
arcpy.CalculateField_management(targetFeatureClass, targetFieldName, defaultTextValue, "PYTHON")

targetFeatureClass = "BCABIRView"
targetFieldName = "EnergyIntensityStatus"
arcpy.AddField_management(targetFeatureClass, targetFieldName, "TEXT")
arcpy.CalculateField_management(targetFeatureClass, targetFieldName, defaultTextValue, "PYTHON")

targetFeatureClass = "BCABIRView"
targetFieldName = "MultipleUseCheck"
arcpy.AddField_management(targetFeatureClass, targetFieldName, "TEXT")
arcpy.CalculateField_management(targetFeatureClass, targetFieldName, defaultTextValue, "PYTHON")

arcpy.SelectLayerByAttribute_management("BCABIRView", "NEW_SELECTION", "TaNDM_Occ_UoM Like '%STRATA PARKING%'")
arcpy.CalculateField_management("BCABIRView", "EnergyIntensityStatus", "'Do not use - strata parking space'", "PYTHON", "")
arcpy.SelectLayerByAttribute_management("BCABIRView", "CLEAR_SELECTION", "")

arcpy.AddMessage("Identified strata parking spaces...")

arcpy.SelectLayerByAttribute_management("BCABIRView", "NEW_SELECTION", "Occupancy = 'STRATA ADDONS'")
arcpy.CalculateField_management("BCABIRView", "EnergyIntensityStatus", "'Do not use - duplicate of STR Strata Lot Area'", "PYTHON", "")
arcpy.SelectLayerByAttribute_management("BCABIRView", "CLEAR_SELECTION", "")

arcpy.AddMessage("Identified strata parking spaces...")

arcpy.DeleteField_management("BCABIRView", ["MajorCategory_occ", "Category_occ", "Sub_category_occ", "MajorCategory_uom", "Category_uom", "Sub_category_uom"])

arcpy.AddMessage("Refined classification based on Occupancy and Unit of Measure...")

arcpy.SelectLayerByAttribute_management("BCABIRView", "NEW_SELECTION", "BuildingType = 'Outbuilding'")
arcpy.CalculateField_management("BCABIRView", "Sub_category", "'Outbuilding'", "PYTHON", "")

arcpy.AddMessage("Refined sub-category for Outbuildings...")

arcpy.SelectLayerByAttribute_management("BCABIRView", "NEW_SELECTION", "YearBuilt <= 1996")
arcpy.CalculateField_management("BCABIRView", "TaNDM_BuildingEra", "1", "PYTHON", "")

arcpy.SelectLayerByAttribute_management("BCABIRView", "NEW_SELECTION", "\"YearBuilt\" IS NULL")
arcpy.CalculateField_management("BCABIRView", "TaNDM_BuildingEra", "1", "PYTHON", "")

arcpy.SelectLayerByAttribute_management("BCABIRView", "NEW_SELECTION", "YearBuilt > 1996 and YearBuilt <= 2006")
arcpy.CalculateField_management("BCABIRView", "TaNDM_BuildingEra", "2", "PYTHON", "")

arcpy.SelectLayerByAttribute_management("BCABIRView", "NEW_SELECTION", "YearBuilt > 2006")
arcpy.CalculateField_management("BCABIRView", "TaNDM_BuildingEra", "3", "PYTHON", "")

arcpy.AddMessage("Assigned building eras...")

arcpy.SelectLayerByAttribute_management("BCABIRView", "NEW_SELECTION", "TaNDM_FloorArea <= 10")
arcpy.CalculateField_management("BCABIRView", "EnergyIntensityStatus", "'Do not use - no floor area'", "PYTHON", "")
arcpy.SelectLayerByAttribute_management("BCABIRView", "CLEAR_SELECTION", "")

arcpy.SelectLayerByAttribute_management("BCABIRView", "NEW_SELECTION", "TaNDM_FloorArea <= 10")
arcpy.CalculateField_management("BCABIRView", "EnergyIntensityStatus", "'Do not use - no floor area'", "PYTHON", "")


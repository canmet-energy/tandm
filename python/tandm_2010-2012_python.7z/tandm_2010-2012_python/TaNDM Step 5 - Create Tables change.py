#Script written by Brett Korteling of Vive le Monde Mapping - brett@vivelemonde.net (Jan 2012 - UPDATED Dec 2012 / Jan 2013)

# Work through the various complicated relationships between energy use, Folios and parcels
# Identify which parcels have only one use occuring on them,
# which have multiple uses and which ones have a Folio (which represents a use)
# that is split over more than one parcel
# Make sure all these possible occurences are identified in the TaNDM_All_Uses table
# and properly identified in the parcel layer
# Also generate some summary tables to compare the match between Folios as found in
# the Assessment Fabric and Folios as found in the BCA Building Information Report
# Assign neighbourhood values to the parcel layer and the TaNDM_All_Uses table

import arcpy
from arcpy import env

# Grab parameters from the tool GUI
inFGDBName   = arcpy.GetParameterAsText(0)

WorkingDirectory = inFGDBName
env.Workspace = WorkingDirectory

# Create names for input layers and remove previous occurrenced of output layers
ParcelCentroidWithNeighbourhoodsFullName = WorkingDirectory + "\\Parcel_CentroidWithFolioPlanningCensus"
arcpy.MakeFeatureLayer_management(ParcelCentroidWithNeighbourhoodsFullName,"ParcelCentroidWithNeighbourhoodsView")

TempPlanningFullname = WorkingDirectory + "\\TempPlanning_layer"

BCABIRFullName = WorkingDirectory + "\\BCABuildingInformationReport"

BCABIRSimplifiedFullName = WorkingDirectory + "\\BCABIRSimplified"

BCABIRUniqueFullName = WorkingDirectory + "\\BCABIRUnique"
BCAMixedUseFullName = WorkingDirectory + "\\BCAMixedUse"

Summary_MultipleUsesPerPID_step1FullName = WorkingDirectory + "\\Summary_MultipleUsesPerPID_step1"
Summary_MultipleUsesPerPID_step2FullName = WorkingDirectory + "\\Summary_MultipleUsesPerPID_step2"
Summary_MultipleUsesPerPID_UniqueFullName = WorkingDirectory + "\\Summary_MultipleUsesPerPID_Unique"
Summary_MultipleUsesPerPIDFullName = WorkingDirectory + "\\Summary_MultipleUsesPerPID"
Summary_MultipleUsesPerPIDFromAssessmentFabricFullName = WorkingDirectory + "\\Summary_MultipleUsesPerPIDFromAssessmentFabric"
Summary_FoliosInAssessmentFabricAndNotFoundInBCATables_Prep_FullName = WorkingDirectory + "\\Summary_FoliosInAssessmentFabricAndNotFoundInBCATables_Prep"
Summary_FoliosInBCATablesAndNotFoundInAssessmentFabric_Prep_FullName = WorkingDirectory + "\\Summary_FoliosInBCATablesAndNotFoundInAssessmentFabric_Prep"
Summary_FoliosInAssessmentFabricAndNotFoundInBCATablesFullName = WorkingDirectory + "\\Summary_FoliosInAssessmentFabricAndNotFoundInBCATables"
Summary_FoliosInBCATablesAndNotFoundInAssessmentFabricFullName = WorkingDirectory + "\\Summary_FoliosInBCATablesAndNotFoundInAssessmentFabric"
Summary_FoliosOverMoreThanOnePIDFullName = WorkingDirectory + "\\Summary_FoliosOverMoreThanOnePID"
Summary_FolioSplitBetweenPIDsFullName = WorkingDirectory + "\\Summary_FolioSplitBetweenPIDs"
Temp_FolioSplitBetweenPIDs_toAddFullName = WorkingDirectory + "\\Temp_FolioSplitBetweenPIDs_toAdd"

ParcelFullName = WorkingDirectory + "\\Parcel"
TaNDMParcelFullName = WorkingDirectory + "\\TaNDM_Parcel"

ParcelCentroidWithFolioFullName = WorkingDirectory + "\\Parcel_CentroidWithFolio"
PIDFolioUniqueFullName = WorkingDirectory + "\\PID_FolioUnique"
AssessmentFabricCentroidWithPIDFullName = WorkingDirectory + "\\BCAssessment_CentroidWithPID"
FolioUniqueFullName = WorkingDirectory + "\\Folio_Unique"
MultipleUsesFromBCAFullName = WorkingDirectory + "\\MultipleUsesFromBCA"
MultipleUsesFromAssessmentFabricFullName = WorkingDirectory + "\\MultipleUsesFromAssessmentFabric"
PIDFromMultipleUsesUniqueFullName = WorkingDirectory + "\\PIDFromMultipleUses_Unique"

PIDFolioUnique_pre1FullName = WorkingDirectory + "\\PID_FolioUnique_pre1"
FolioPIDUnique_pre1FullName = WorkingDirectory + "\\FolioPIDUnique_pre1"
FolioPIDUnique_pre2FullName = WorkingDirectory + "\\FolioPIDUnique_pre2"

if arcpy.Exists(BCABIRSimplifiedFullName):
    arcpy.Delete_management(BCABIRSimplifiedFullName, "Table")

if arcpy.Exists(BCABIRUniqueFullName):
    arcpy.Delete_management(BCABIRUniqueFullName, "Table")

if arcpy.Exists(PIDFolioUniqueFullName):
    arcpy.Delete_management(PIDFolioUniqueFullName, "Table")

if arcpy.Exists(PIDFolioUnique_pre1FullName):
    arcpy.Delete_management(PIDFolioUnique_pre1FullName, "Table")

if arcpy.Exists(FolioPIDUnique_pre1FullName):
    arcpy.Delete_management(FolioPIDUnique_pre1FullName, "Table")

if arcpy.Exists(FolioPIDUnique_pre2FullName):
    arcpy.Delete_management(FolioPIDUnique_pre2FullName, "Table")

if arcpy.Exists(MultipleUsesFromBCAFullName):
    arcpy.Delete_management(MultipleUsesFromBCAFullName, "Table")

if arcpy.Exists(MultipleUsesFromAssessmentFabricFullName):
    arcpy.Delete_management(MultipleUsesFromAssessmentFabricFullName, "Table")
    
if arcpy.Exists(FolioUniqueFullName):
    arcpy.Delete_management(FolioUniqueFullName, "Table")
    
if arcpy.Exists(BCAMixedUseFullName):
    arcpy.Delete_management(BCAMixedUseFullName, "Table")

if arcpy.Exists(Summary_FolioSplitBetweenPIDsFullName):
    arcpy.Delete_management(Summary_FolioSplitBetweenPIDsFullName, "Table")

if arcpy.Exists(Summary_MultipleUsesPerPIDFullName):
    arcpy.Delete_management(Summary_MultipleUsesPerPIDFullName, "Table")

if arcpy.Exists(Summary_MultipleUsesPerPID_step1FullName):
    arcpy.Delete_management(Summary_MultipleUsesPerPID_step1FullName, "Table")
    
if arcpy.Exists(Summary_MultipleUsesPerPID_step2FullName):
    arcpy.Delete_management(Summary_MultipleUsesPerPID_step2FullName, "Table")
    
if arcpy.Exists(Summary_MultipleUsesPerPID_UniqueFullName):
    arcpy.Delete_management(Summary_MultipleUsesPerPID_UniqueFullName, "Table")

if arcpy.Exists(Summary_MultipleUsesPerPIDFromAssessmentFabricFullName):
    arcpy.Delete_management(Summary_MultipleUsesPerPIDFromAssessmentFabricFullName, "Table")

if arcpy.Exists(Summary_FoliosInAssessmentFabricAndNotFoundInBCATables_Prep_FullName):
    arcpy.Delete_management(Summary_FoliosInAssessmentFabricAndNotFoundInBCATables_Prep_FullName, "Table")

if arcpy.Exists(Summary_FoliosInBCATablesAndNotFoundInAssessmentFabric_Prep_FullName):
    arcpy.Delete_management(Summary_FoliosInBCATablesAndNotFoundInAssessmentFabric_Prep_FullName, "Table")

if arcpy.Exists(Summary_FoliosInAssessmentFabricAndNotFoundInBCATablesFullName):
    arcpy.Delete_management(Summary_FoliosInAssessmentFabricAndNotFoundInBCATablesFullName, "Table")

if arcpy.Exists(Summary_FoliosInBCATablesAndNotFoundInAssessmentFabricFullName):
    arcpy.Delete_management(Summary_FoliosInBCATablesAndNotFoundInAssessmentFabricFullName, "Table")

if arcpy.Exists(Summary_FoliosOverMoreThanOnePIDFullName):
    arcpy.Delete_management(Summary_FoliosOverMoreThanOnePIDFullName, "Table")

if arcpy.Exists(PIDFromMultipleUsesUniqueFullName):
    arcpy.Delete_management(PIDFromMultipleUsesUniqueFullName, "Table")

if arcpy.Exists(Temp_FolioSplitBetweenPIDs_toAddFullName):
    arcpy.Delete_management(Temp_FolioSplitBetweenPIDs_toAddFullName, "Table")

if arcpy.Exists(TaNDMParcelFullName):
    arcpy.Delete_management(TaNDMParcelFullName, "Feature Class")
arcpy.FeatureClassToFeatureClass_conversion(ParcelFullName, WorkingDirectory, "TaNDM_Parcel", "")

arcpy.MakeFeatureLayer_management(TaNDMParcelFullName,"TaNDM_ParcelView")
   
# Create unique listing of PID to Folio many-to-many relationship
arcpy.Frequency_analysis(ParcelCentroidWithFolioFullName, PIDFolioUnique_pre1FullName, "TaNDM_Unique;TaNDM_Folio", "")
arcpy.Frequency_analysis(AssessmentFabricCentroidWithPIDFullName, FolioPIDUnique_pre1FullName, "TaNDM_Unique;TaNDM_Folio", "")

arcpy.TableToTable_conversion(FolioPIDUnique_pre1FullName, WorkingDirectory, "FolioPIDUnique_pre2", "")

arcpy.Append_management(PIDFolioUnique_pre1FullName, FolioPIDUnique_pre2FullName, "NO_TEST", "", "")

arcpy.Frequency_analysis(FolioPIDUnique_pre2FullName, PIDFolioUniqueFullName, "TaNDM_Unique;TaNDM_Folio", "")

targetFeatureClass = PIDFolioUniqueFullName
targetFieldName = "TaNDM_PID_Folio"
defaultTextValue = "'Unassigned'"
arcpy.AddField_management(targetFeatureClass, targetFieldName, "TEXT")
arcpy.CalculateField_management(targetFeatureClass, targetFieldName, "!TaNDM_Unique! + '-' + !TaNDM_Folio!", "PYTHON")


# Create unique listing of residential and commercial inventories
arcpy.TableToTable_conversion(BCABIRFullName, WorkingDirectory, "BCABIRSimplified", "", "TaNDM_AUC \"TaNDM_AUC\" true true false 255 Text 0 0 ,First,#," + BCABIRFullName + ",TaNDM_AUC,-1,-1;TaNDM_MCC \"TaNDM_MCC\" true true false 255 Text 0 0 ,First,#," + BCABIRFullName + ",TaNDM_MCC,-1,-1; MajorCategory \"MajorCategory\" true true false 255 Text 0 0 ,First,#," + BCABIRFullName + ", MajorCategory,-1,-1;Category \"Category\" true true false 255 Text 0 0 ,First,#," + BCABIRFullName + ",Category,-1,-1;Sub_category \"Sub_category\" true true false 255 Text 0 0 ,First,#," + BCABIRFullName + ",Sub_category,-1,-1;TaNDM_Folio \"TaNDM_Folio\" true true false 50 Text 0 0 ,First,#," + BCABIRFullName + ",TaNDM_Folio,-1,-1; YearBuilt \"YearBuilt\" true true false 4 Long 0 0 ,First,#," + BCABIRFullName + ",YearBuilt,-1,-1; TaNDM_BuildingEra \"TaNDM_BuildingEra\" true true false 4 Long 0 0 ,First,#," + BCABIRFullName + ",TaNDM_BuildingEra,-1,-1; TaNDM_NosUnits \"TaNDM_NosUnits\" true true false 4 Long 0 0 ,First,#," + BCABIRFullName + ",TaNDM_NosUnits,-1,-1;TaNDM_FloorArea \"\" true true false 4 Long 0 0 ,First,#," + BCABIRFullName + ",TaNDM_FloorArea,-1,-1; TaNDM_FloorAreaType \"TaNDM_FloorAreaType\" true true false 255 Text 0 0 ,First,#," + BCABIRFullName + ",TaNDM_FloorAreaType,-1,-1;EnergyIntensityStatus \"EnergyIntensityStatus\" true true false 255 Text 0 0 ,First,#," + BCABIRFullName + ",EnergyIntensityStatus,-1,-1", "")

arcpy.Frequency_analysis(BCABIRSimplifiedFullName, BCABIRUniqueFullName, "TaNDM_Folio;TaNDM_AUC;TaNDM_MCC;MajorCategory;Category;Sub_category;YearBuilt;TaNDM_BuildingEra;TaNDM_NosUnits;TaNDM_FloorArea;TaNDM_FloorAreaType;EnergyIntensityStatus", "")

# Assign PID to BCA Unique table based on Folio relationship from many-to-many tables
# in order to assign neighbourhoods to folios in this master table
# If a Folio exists on more than one parcel, then only the first PID will be assigned
# there will only be a problem if the folio
arcpy.JoinField_management(BCABIRUniqueFullName, "TaNDM_Folio", PIDFolioUniqueFullName, "TaNDM_Folio", ["TaNDM_Unique","TaNDM_PID_Folio"])
arcpy.AddMessage("Created unique BCA BIR and PID/Folio tables...")

arcpy.JoinField_management(BCABIRUniqueFullName, "TaNDM_Folio", ParcelCentroidWithNeighbourhoodsFullName, "TaNDM_Folio", ["TaNDM_PlanningNeighbourhood","TaNDM_CensusNeighbourhood"])
arcpy.JoinField_management(TaNDMParcelFullName, "TaNDM_Unique", ParcelCentroidWithNeighbourhoodsFullName, "TaNDM_Unique", ["TaNDM_PlanningNeighbourhood","TaNDM_CensusNeighbourhood"])
arcpy.AddMessage("Added neighbourhoods to TaNDM_parcel layer and TaNDM_BCA table...")

arcpy.MakeTableView_management(BCABIRUniqueFullName,"BCABIRUniqueView")

targetFeatureClass = "TaNDM_ParcelView"
targetFieldName = "MatchResult"
defaultTextValue = "'Unassigned'"
arcpy.AddField_management(targetFeatureClass, targetFieldName, "TEXT")
arcpy.CalculateField_management(targetFeatureClass, targetFieldName, defaultTextValue, "PYTHON")

targetFeatureClass = "TaNDM_ParcelView"
targetFieldName = "EnergyIntensityStatus"
arcpy.AddField_management(targetFeatureClass, targetFieldName, "TEXT")
arcpy.CalculateField_management(targetFeatureClass, targetFieldName, defaultTextValue, "PYTHON")

targetFeatureClass = "BCABIRUniqueView"
targetFieldName = "MatchResult"
defaultTextValue = "'Unassigned'"
arcpy.AddField_management(targetFeatureClass, targetFieldName, "TEXT")
arcpy.CalculateField_management(targetFeatureClass, targetFieldName, defaultTextValue, "PYTHON")

# Create summary tables to record which Folios exist in the Assessment fabric and not in the BCA tables and vice versa
arcpy.MakeTableView_management(PIDFolioUniqueFullName,"PIDFolioUniqueView")

targetFeatureClass = "PIDFolioUniqueView"
defaultNumberValue = "0"
defaultTextValue = "'Yes'"

targetFieldName = "Folio_InAssessmentFabric"
arcpy.AddField_management(targetFeatureClass, targetFieldName, "TEXT")
arcpy.SelectLayerByAttribute_management("PIDFolioUniqueView", "NEW_SELECTION", "TaNDM_Folio <> ''")
arcpy.CalculateField_management(targetFeatureClass, targetFieldName, defaultTextValue, "PYTHON")
arcpy.SelectLayerByAttribute_management("PIDFolioUniqueView", "CLEAR_SELECTION", "")

targetFeatureClass = "BCABIRUniqueView" 
defaultNumberValue = "0"
defaultTextValue = "'Yes'"

targetFieldName = "Folio_InBCATables" 
arcpy.AddField_management(targetFeatureClass, targetFieldName, "TEXT")
arcpy.CalculateField_management(targetFeatureClass, targetFieldName, defaultTextValue, "PYTHON")
arcpy.SelectLayerByAttribute_management("BCABIRUniqueView", "CLEAR_SELECTION", "")

# Create a relationship between Assessment Fabric and BCA tables and export a summary table where the BCA tables are missing a Folio that is found in the Assessment Fabric
arcpy.JoinField_management(PIDFolioUniqueFullName, "TaNDM_PID_Folio", BCABIRUniqueFullName, "TaNDM_PID_Folio", ["Folio_InBCATables"])
arcpy.TableToTable_conversion("PIDFolioUniqueView", WorkingDirectory, "Summary_FoliosInAssessmentFabricAndNotFoundInBCATables_Prep", "\"Folio_InBCATables\" IS NULL and \"TaNDM_Folio\" IS NOT NULL", "TaNDM_Unique \"TaNDM_Unique\" true true false 255 Text 0 0 ,First,#," + PIDFolioUniqueFullName + ",TaNDM_Unique,-1,-1;TaNDM_Folio \"TaNDM_Folio\" true true false 255 Text 0 0 ,First,#," + PIDFolioUniqueFullName + ",TaNDM_Folio,-1,-1", "")
arcpy.Frequency_analysis(Summary_FoliosInAssessmentFabricAndNotFoundInBCATables_Prep_FullName, Summary_FoliosInAssessmentFabricAndNotFoundInBCATablesFullName, "TaNDM_Unique; TaNDM_Folio", "")
arcpy.AddMessage("Created Summary_FoliosInAssessmentFabricAndNotFoundInBCATables...")

                 
# Create a reciprocal relationship between BCA tables and the Assessment Fabric and export a summary table where the Assessment Fabric is missing Folios that are found in the BCA tables
arcpy.JoinField_management(BCABIRUniqueFullName, "TaNDM_PID_Folio", PIDFolioUniqueFullName, "TaNDM_PID_Folio", ["Folio_InAssessmentFabric"])
arcpy.TableToTable_conversion("BCABIRUniqueView", WorkingDirectory, "Summary_FoliosInBCATablesAndNotFoundInAssessmentFabric_Prep", "\"Folio_InAssessmentFabric\" IS NULL and \"TaNDM_Folio\" IS NOT NULL", "TaNDM_Folio \"TaNDM_Folio\" true true false 50 Text 0 0 ,First,#," + BCABIRUniqueFullName +",TaNDM_Folio,-1,-1;TaNDM_Unique \"TaNDM_Unique\" true true false 255 Text 0 0 ,First,#,"+ BCABIRUniqueFullName + ",TaNDM_Unique,-1,-1", "")
arcpy.Frequency_analysis(Summary_FoliosInBCATablesAndNotFoundInAssessmentFabric_Prep_FullName, Summary_FoliosInBCATablesAndNotFoundInAssessmentFabricFullName, "TaNDM_Unique; TaNDM_Folio", "")
arcpy.AddMessage("Created Summary_FoliosInBCATablesAndNotFoundInAssessmentFabric...")


# Add the other PIDs connected to Folios that are assigned to more than one PID
# the previous joins allow only the first PID connected with a follow to be part of the TaNDM_All_Uses master table

# Create a listing of all Folios that exist for more than on PID from the many-to-many PID Folio table
arcpy.Frequency_analysis(PIDFolioUniqueFullName, FolioUniqueFullName, "TaNDM_Folio", "")
arcpy.TableSelect_analysis (FolioUniqueFullName, Summary_FoliosOverMoreThanOnePIDFullName, "FREQUENCY > 1 and TaNDM_Folio <> ''")
arcpy.MakeTableView_management(Summary_FoliosOverMoreThanOnePIDFullName,"Summary_FoliosOverMoreThanOnePIDView")

targetFeatureClass = "Summary_FoliosOverMoreThanOnePIDView"
defaultNumberValue = "0"
defaultTextValue = "'FoliosOverManyParcels'"

targetFieldName = "Folios_Split"
arcpy.AddField_management(targetFeatureClass, targetFieldName, "TEXT")
arcpy.CalculateField_management(targetFeatureClass, targetFieldName, defaultTextValue, "PYTHON")

# Identify the Folios that are split over more than one parcel in the many-to-many PID Folio table and create a full listing of these with all their associated PIDs
arcpy.JoinField_management(PIDFolioUniqueFullName, "TaNDM_Folio", Summary_FoliosOverMoreThanOnePIDFullName, "TaNDM_Folio", ["Folios_Split"])
arcpy.TableSelect_analysis (PIDFolioUniqueFullName, Summary_FolioSplitBetweenPIDsFullName, "Folios_Split = 'FoliosOverManyParcels'")
arcpy.MakeTableView_management(Summary_FolioSplitBetweenPIDsFullName,"Summary_FolioSplitBetweenPIDsView")

arcpy.AddMessage("Created Summary_FolioSplitBetweenPIDs to identify PIDs that have folios that are assigned to more than one parcel...")
# The second part of dealing with folios split over parcels occurs later in the script to make sure all energy uses are connected to all PIDs in the parcel layer
# and to make sure that all PIDs are represented in the TaNDM_All_Uses table

# Create a table to identify when more than one folio occurs on a parcel
# GET TANDM UNIQUE AND SUB_CATEGORY TOGETHER TO GENERATE IDENTIFICATION OF MULTIPLES!
arcpy.SelectLayerByAttribute_management("BCABIRUniqueView", "NEW_SELECTION", "EnergyIntensityStatus LIKE 'Do not use%'")
arcpy.SelectLayerByAttribute_management("BCABIRUniqueView", "SWITCH_SELECTION", "")
arcpy.Statistics_analysis(BCABIRUniqueFullName, Summary_MultipleUsesPerPID_step1FullName, "TaNDM_FloorArea SUM;TaNDM_NosUnits SUM", "TaNDM_Unique;Sub_category;TaNDM_BuildingEra;TaNDM_FloorAreaType")
arcpy.Frequency_analysis(Summary_MultipleUsesPerPID_step1FullName, MultipleUsesFromBCAFullName, "TaNDM_Unique", "")
arcpy.TableSelect_analysis (MultipleUsesFromBCAFullName, Summary_MultipleUsesPerPID_step2FullName, "FREQUENCY > 1")
arcpy.SelectLayerByAttribute_management("BCABIRUniqueView", "CLEAR_SELECTION", "")

arcpy.AddMessage("Created Summary_MultipleUsesPerPID step2 to identify parcels that have more than one use occurring...")

arcpy.MakeTableView_management(Summary_MultipleUsesPerPID_step2FullName,"Summary_MultipleUsesPerPID_step2View")

targetFeatureClass = "Summary_MultipleUsesPerPID_step2View"
defaultNumberValue = "0"
defaultTextValue = "'Multiple'"

arcpy.SelectLayerByAttribute_management("Summary_MultipleUsesPerPID_step2View", "NEW_SELECTION", "\"TaNDM_Unique\" IS NULL")
if arcpy.GetCount_management("Summary_MultipleUsesPerPID_step2View") > 0:
       arcpy.DeleteRows_management("Summary_MultipleUsesPerPID_step2View")

targetFieldName = "Number_Of_Uses"
arcpy.AddField_management(targetFeatureClass, targetFieldName, "TEXT")
arcpy.CalculateField_management(targetFeatureClass, targetFieldName, defaultTextValue, "PYTHON")

# Identify the PIDs that have multiple uses in the many-to-many PID Folio unique table and the TaNDM_All_Uses table
arcpy.JoinField_management(PIDFolioUniqueFullName, "TaNDM_Unique", Summary_MultipleUsesPerPID_step2FullName, "TaNDM_Unique", ["Number_Of_Uses"])
arcpy.TableSelect_analysis (PIDFolioUniqueFullName, Summary_MultipleUsesPerPIDFullName, "Number_Of_Uses = 'Multiple'")

targetFeatureClass = Summary_MultipleUsesPerPIDFullName
defaultNumberValue = "0"
defaultTextValue = "'Unassigned'"

arcpy.MakeTableView_management(Summary_MultipleUsesPerPIDFullName,"Summary_MultipleUsesPerPIDView")

targetFieldName = "Temp_Number_Of_Uses"
arcpy.AddField_management(targetFeatureClass, targetFieldName, "TEXT")
arcpy.CalculateField_management(targetFeatureClass, targetFieldName, "'Multiple'", "PYTHON")




# Add categories from the TaNDM_All_Uses table to the parcel layer
# Identify which parcels have more than one use occuring and refer to the TaNDM_All_Uses table to ensure
# there is proper counting of all energy use
arcpy.JoinField_management(TaNDMParcelFullName, "TaNDM_Unique", BCABIRUniqueFullName, "TaNDM_Unique", ["MajorCategory", "Category", "Sub_category", "TaNDM_FloorArea", "TaNDM_FloorAreaType", "TaNDM_BuildingEra", "TaNDM_NosUnits"])
# To start, identify all Folios in the TaNDM_All_Uses table as a single use 'Single'
targetFeatureClass = "TaNDM_ParcelView"
defaultNumberValue = "0"
defaultTextValue = "'Single'"

targetFieldName = "Number_Of_Uses"
arcpy.AddField_management(targetFeatureClass, targetFieldName, "TEXT")
arcpy.CalculateField_management(targetFeatureClass, targetFieldName, defaultTextValue, "PYTHON")

arcpy.JoinField_management(TaNDMParcelFullName, "TaNDM_Unique", Summary_MultipleUsesPerPIDFullName, "TaNDM_Unique", ["Temp_Number_Of_Uses"])
arcpy.SelectLayerByAttribute_management("TaNDM_ParcelView", "NEW_SELECTION", "Temp_Number_Of_Uses = 'Multiple'")
arcpy.CalculateField_management("TaNDM_ParcelView", "Number_Of_Uses", "!Temp_Number_Of_Uses!", "PYTHON", "")
arcpy.SelectLayerByAttribute_management("TaNDM_ParcelView", "CLEAR_SELECTION", "")
arcpy.DeleteField_management("TaNDM_ParcelView", ["Temp_Number_Of_Uses"])

# Add Folio numbers to the parcel layer via the PID to be able to identify when split uses occur
arcpy.JoinField_management(TaNDMParcelFullName, "TaNDM_Unique", PIDFolioUniqueFullName, "TaNDM_Unique", ["TaNDM_Folio"])

targetFeatureClass = "Summary_FolioSplitBetweenPIDsView"
targetFieldName = "Number_Of_Uses"
arcpy.AddField_management(targetFeatureClass, targetFieldName, "TEXT")

# Identify in the summary table of all split folios whether they are multiple and split or simply just split uses in preparation for identifying them properly in the parcel layer
arcpy.JoinField_management(Summary_FolioSplitBetweenPIDsFullName, "TaNDM_Folio", BCABIRUniqueFullName, "TaNDM_Folio", ["TaNDM_AUC", "TaNDM_MCC", "MajorCategory", "Category", "Sub_category", "MatchResult", "EnergyIntensityStatus"])
arcpy.SelectLayerByAttribute_management("Summary_FolioSplitBetweenPIDsView", "NEW_SELECTION", "\"TaNDM_AUC\" IS NOT NULL")
arcpy.CalculateField_management("Summary_FolioSplitBetweenPIDsView", "Number_Of_Uses", "'Use is split - '" + "!TaNDM_Folio!", "PYTHON", "")
arcpy.SelectLayerByAttribute_management("Summary_FolioSplitBetweenPIDsView", "NEW_SELECTION", "\"TaNDM_AUC\" IS NULL")
arcpy.CalculateField_management("Summary_FolioSplitBetweenPIDsView", "Number_Of_Uses", "'No use assigned and folio is split - '" + "!TaNDM_Folio!", "PYTHON", "")
arcpy.SelectLayerByAttribute_management("Summary_FolioSplitBetweenPIDsView", "CLEAR_SELECTION", "")

# add temp fields to Summary_FolioSplitBetweenPIDsFullName to facilitate calculation accross to the parcel layer and
# ensure that every parcel that has a split use associated with it, is identified with that use
targetFeatureClass = "Summary_FolioSplitBetweenPIDsView"

targetFieldName = "Temp_MajorCategory"
arcpy.AddField_management(targetFeatureClass, targetFieldName, "TEXT")
arcpy.CalculateField_management(targetFeatureClass, "Temp_MajorCategory", "!MajorCategory!", "PYTHON", "")

targetFieldName = "Temp_Category"
arcpy.AddField_management(targetFeatureClass, targetFieldName, "TEXT")
arcpy.CalculateField_management(targetFeatureClass, "Temp_Category", "!Category!", "PYTHON", "")

targetFieldName = "Temp_Subcategory"
arcpy.AddField_management(targetFeatureClass, targetFieldName, "TEXT")
arcpy.CalculateField_management(targetFeatureClass, "Temp_Subcategory", "!Sub_category!", "PYTHON", "")

targetFieldName = "Temp_Number_Of_Uses"
arcpy.AddField_management(targetFeatureClass, targetFieldName, "TEXT")
arcpy.CalculateField_management(targetFeatureClass, "Temp_Number_Of_Uses", "!Number_Of_Uses!", "PYTHON", "")

arcpy.JoinField_management(TaNDMParcelFullName, "TaNDM_Unique", Summary_FolioSplitBetweenPIDsFullName, "TaNDM_Unique", ["Folios_Split","Temp_MajorCategory", "Temp_Category", "Temp_Subcategory", "Temp_Number_Of_Uses"])

# Assign all uses associated with split use to the parcel layer
arcpy.SelectLayerByAttribute_management("TaNDM_ParcelView", "NEW_SELECTION", "Folios_Split = 'FoliosOverManyParcels'")
arcpy.CalculateField_management("TaNDM_ParcelView", "Number_Of_Uses", "!Temp_Number_Of_Uses!", "PYTHON", "")
arcpy.CalculateField_management("TaNDM_ParcelView", "MajorCategory", "!Temp_MajorCategory!", "PYTHON", "")
arcpy.CalculateField_management("TaNDM_ParcelView", "Category", "!Temp_Category!", "PYTHON", "")
arcpy.CalculateField_management("TaNDM_ParcelView", "Sub_category", "!Temp_Subcategory!", "PYTHON", "")
arcpy.SelectLayerByAttribute_management("TaNDM_ParcelView", "CLEAR_SELECTION", "")
arcpy.AddMessage("Assigned type of use to parcel layer...")

# Get rid of unnecessary fields in preparation to export the TaNDM_All_Uses table

arcpy.JoinField_management(BCABIRUniqueFullName, "TaNDM_Unique", Summary_FolioSplitBetweenPIDsFullName, "TaNDM_Unique", ["Folios_Split"])

# Get rid of temporary fields that assisted with calculation
arcpy.DeleteField_management("TaNDM_ParcelView", ["Temp_MajorCategory", "Temp_Category", "Temp_Subcategory", "Temp_Number_Of_Uses"])
arcpy.DeleteField_management("BCABIRUniqueView", ["Temp_MajorCategory", "Temp_Category", "Temp_Subcategory"])
arcpy.DeleteField_management("PIDFolioUniqueView", ["Folio_InAssessmentFabric"])
arcpy.DeleteField_management("BCABIRUniqueView", ["FREQUENCY", "Folio_InBCATables"])
arcpy.DeleteField_management("Summary_FolioSplitBetweenPIDsView", ["Temp_MajorCategory", "Temp_Category", "Temp_Subcategory", "Temp_Number_Of_Uses"])
# add new attribute fields

targetFeatureClass = "TaNDM_ParcelView"
defaultTextValue = "'No MultipleUse'"

targetFieldName = "MultipleSubCat"
arcpy.AddField_management(targetFeatureClass, targetFieldName, "TEXT")
arcpy.CalculateField_management(targetFeatureClass, targetFieldName, defaultTextValue, "PYTHON", "")

targetFieldName = "MultipleFloorArea"
arcpy.AddField_management(targetFeatureClass, targetFieldName, "TEXT")
arcpy.CalculateField_management(targetFeatureClass, targetFieldName, defaultTextValue, "PYTHON", "")

targetFieldName = "MultipleFloorAreaType"
arcpy.AddField_management(targetFeatureClass, targetFieldName, "TEXT")
arcpy.CalculateField_management(targetFeatureClass, targetFieldName, defaultTextValue, "PYTHON", "")

targetFieldName = "MultipleBuildingEra"
arcpy.AddField_management(targetFeatureClass, targetFieldName, "TEXT")
arcpy.CalculateField_management(targetFeatureClass, targetFieldName, defaultTextValue, "PYTHON", "")

targetFieldName = "MultipleNosUnits"
arcpy.AddField_management(targetFeatureClass, targetFieldName, "TEXT")
arcpy.CalculateField_management(targetFeatureClass, targetFieldName, defaultTextValue, "PYTHON", "")
#for all multiple use (split over many folios and existing on one folio) add the multiple information to the multiple fields
rows = arcpy.SearchCursor(Summary_MultipleUsesPerPID_step2FullName, "", "", "TaNDM_Unique", "TaNDM_Unique D")
for row in rows:
    theTaNDM_Unique = row.TaNDM_Unique
    
    Sub_category_all = ""
    FloorArea_all = ""
    FloorAreaType_all = ""
    BuildingEra_all = ""
    NosUnits_all = ""
    rows = arcpy.SearchCursor(Summary_MultipleUsesPerPID_step1FullName, "TaNDM_Unique = '" + theTaNDM_Unique + "'", "", "Sub_category; SUM_TaNDM_FloorArea; TaNDM_FloorAreaType; TaNDM_BuildingEra; SUM_TaNDM_NosUnits" , "TaNDM_Unique D")
    count = 0
    for row in rows:
        count = count + 1
        
        theSub_category = row.Sub_category
        if theSub_category is None:
                    theSub_category = "NA"
        theFloorArea = str(row.SUM_TaNDM_FloorArea)
        if theFloorArea is None:
                    theFloorArea = "NA"
        theFloorAreaType = row.TaNDM_FloorAreaType
        if theFloorAreaType is None:
                    theFloorAreaType = "NA"
        theBuildingEra = str(row.TaNDM_BuildingEra)
        if theBuildingEra is None:
                    theBuildingEra = "NA"
        theNosUnits = str(row.SUM_TaNDM_NosUnits)
        if theNosUnits is None:
                    theNosUnits = "NA"
        
        
        if count == 1:
            Sub_category_all = theSub_category
        else:
            Sub_category_all = Sub_category_all + ", " + theSub_category
        
        if count == 1:
            FloorArea_all = theFloorArea
        else:
            FloorArea_all = FloorArea_all + ", " + theFloorArea
            
        if count == 1:
            FloorAreaType_all = theFloorAreaType
        else:
            FloorAreaType_all = FloorAreaType_all + ", " + theFloorAreaType
                
        if count == 1:
            BuildingEra_all = theBuildingEra
        else:
            BuildingEra_all = BuildingEra_all + ", " + theBuildingEra
            
        if count == 1:
            NosUnits_all = theNosUnits
        else:
            NosUnits_all = NosUnits_all + ", " + theNosUnits
       
    rows = arcpy.UpdateCursor (TaNDMParcelFullName, "TaNDM_Unique = '" + theTaNDM_Unique + "'", "", "MajorCategory; Category; Sub_category; TaNDM_FloorArea; TaNDM_FloorAreaType; TaNDM_BuildingEra; TaNDM_NosUnits; MultipleSubCat; MultipleFloorArea; MultipleFloorAreaType; MultipleBuildingEra; MultipleNosUnits; TaNDM_Folio" , "TaNDM_Unique D")
    for row in rows:
        row.MultipleSubCat = Sub_category_all
        row.MultipleFloorArea = FloorArea_all
        row.MultipleFloorAreaType = FloorAreaType_all
        row.MultipleBuildingEra = BuildingEra_all
        row.MultipleNosUnits = NosUnits_all
        
        row.MajorCategory = "'MultipleUses'"
        row.Category = "'MultipleUses'"
        row.Sub_category = "'MultipleUses'"
        row.TaNDM_FloorArea = "9999"
        row.TaNDM_FloorAreaType = "'MultipleUses'"
        row.TaNDM_BuildingEra = "9999"
        row.TaNDM_NosUnits = "9999"
        rows.updateRow(row)    
        rows = arcpy.SearchCursor(TaNDMParcelFullName, "TaNDM_Unique = '" + theTaNDM_Unique + "'", "", "Folios_Split; MajorCategory; Category; Sub_category; TaNDM_FloorArea; TaNDM_FloorAreaType; TaNDM_BuildingEra; TaNDM_NosUnits; MultipleSubCat; MultipleFloorArea; MultipleFloorAreaType; MultipleBuildingEra; MultipleNosUnits; TaNDM_Folio" , "TaNDM_Unique D")
        count = 0
        for row in rows:
            count = count + 1
            theFoliosSplit = row.Folios_Split
            theSecondTaNDM_Folio = row.TaNDM_Folio
            if theSecondTaNDM_Folio is None:
                    theSecondTaNDM_Folio = "1111111"
                    
            if theFoliosSplit == "FoliosOverManyParcels":
                rows = arcpy.UpdateCursor (TaNDMParcelFullName, "TaNDM_Folio = '" + theSecondTaNDM_Folio + "'", "", "Folios_Split; MajorCategory; Category; Sub_category; TaNDM_FloorArea; TaNDM_FloorAreaType; TaNDM_BuildingEra; TaNDM_NosUnits; MultipleSubCat; MultipleFloorArea; MultipleFloorAreaType; MultipleBuildingEra; MultipleNosUnits; TaNDM_Folio" , "TaNDM_Unique D")
                for row in rows:
                    row.MultipleSubCat = Sub_category_all
                    row.MultipleFloorArea = FloorArea_all
                    row.MultipleFloorAreaType = FloorAreaType_all
                    row.MultipleBuildingEra = BuildingEra_all
                    row.MultipleNosUnits = NosUnits_all
                    
                    row.MajorCategory = "'MultipleUses'"
                    row.Category = "'MultipleUses'"
                    row.Sub_category = "'MultipleUses'"
                    row.TaNDM_FloorArea = "9999"
                    row.TaNDM_FloorAreaType = "'MultipleUses'"
                    row.TaNDM_BuildingEra = "9999"
                    row.TaNDM_NosUnits = "9999"
                    row.TaNDM_Folio = "'MultipleUses and Split'"
                    rows.updateRow(row)
            else:   
                rows = arcpy.UpdateCursor (TaNDMParcelFullName, "TaNDM_Folio = '" + theSecondTaNDM_Folio + "'", "", "MultipleSubCat; MultipleFloorArea; MultipleFloorAreaType; MultipleBuildingEra; MultipleNosUnits; TaNDM_Folio" , "TaNDM_Unique D")
                for row in rows:
                    row.TaNDM_Folio = "'MultipleUses'"
                    rows.updateRow(row)

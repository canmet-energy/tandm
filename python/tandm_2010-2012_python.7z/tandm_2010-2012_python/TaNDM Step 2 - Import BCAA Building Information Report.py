#Script written by Brett Korteling of Vive le Monde Mapping - brett@vivelemonde.net (October 2012)

# Create a table in a File Geodatabase, add fields and import the data from a text file
# 

import arcpy
import os
import fileinput
import string
from arcpy import env

# Grab parameters from the tool GUI
inFGDBName   = arcpy.GetParameterAsText(0)
inBCAATextFileFolder  = arcpy.GetParameterAsText(1)
inNameofBCAAFile = "BCABuildingInformationReport"

# Set the workspace
theGeodatabase = inFGDBName

WorkingDirectory = inFGDBName
env.workspace = inFGDBName

BCAATableShortName = inNameofBCAAFile
BCAATableName = inFGDBName + "\\" + inNameofBCAAFile
GBAAreaFrequencyTableName = inFGDBName + "\\GBA_Area_Frequency"

arcpy.AddMessage("Creating table " + inNameofBCAAFile + " from the following BCAA Building Information Report text files...")
   
os.chdir(inBCAATextFileFolder)
listOfBCAABIRTextFiles =[]
for files in os.listdir("."):
    if files.endswith(".txt"):
        arcpy.AddMessage(files)
        listOfBCAABIRTextFiles.append(files)

#arcpy.AddMessage(listOfBCAABIRTextFiles)

if arcpy.Exists(BCAATableName):
    arcpy.Delete_management(BCAATableName, "Table")

if arcpy.Exists(GBAAreaFrequencyTableName):
    arcpy.Delete_management(GBAAreaFrequencyTableName, "Table")

# Execute CreateTable
arcpy.CreateTable_management(inFGDBName, BCAATableShortName, "", "")

# Execute AddField twice for two new fields
arcpy.AddField_management(BCAATableName, "Area", "TEXT", "", "", 2)
arcpy.AddField_management(BCAATableName, "Jur", "TEXT", "", "", 3)
arcpy.AddField_management(BCAATableName, "Roll", "TEXT", "", "", 15)
arcpy.AddField_management(BCAATableName, "CivicAddress", "TEXT", "", "", 255)
arcpy.AddField_management(BCAATableName, "PID", "TEXT", "", "", 255)
arcpy.AddField_management(BCAATableName, "LegalDesc", "TEXT", "", "", 1500)
arcpy.AddField_management(BCAATableName, "LotDimensions", "TEXT", "", "", 50)
arcpy.AddField_management(BCAATableName, "LandSize", "DOUBLE", "", "", "",
                          "", "NULLABLE")
arcpy.AddField_management(BCAATableName, "LandDepth", "DOUBLE", "", "", "",
                          "", "NULLABLE")
arcpy.AddField_management(BCAATableName, "PrimAUC", "TEXT", "", "", 3)
arcpy.AddField_management(BCAATableName, "BuildingType", "TEXT", "", "", 50)
arcpy.AddField_management(BCAATableName, "MCC", "TEXT", "", "", 4)
arcpy.AddField_management(BCAATableName, "YearBuilt", "LONG", "", "", "",
                          "", "NULLABLE")
arcpy.AddField_management(BCAATableName, "EffectiveYear", "LONG", "", "", "",
                          "", "NULLABLE")
arcpy.AddField_management(BCAATableName, "TotalArea", "DOUBLE", "", "", "",
                          "", "NULLABLE")
arcpy.AddField_management(BCAATableName, "FoundationArea", "DOUBLE", "", "", "",
                          "", "NULLABLE")
arcpy.AddField_management(BCAATableName, "Occupancy", "TEXT", "", "", 100)
arcpy.AddField_management(BCAATableName, "UnitOfMeasure", "TEXT", "", "", 50)
arcpy.AddField_management(BCAATableName, "NosUnits", "DOUBLE", "", "", "",
                          "", "NULLABLE")
arcpy.AddField_management(BCAATableName, "StrataUnitArea", "DOUBLE", "", "", "",
                          "", "NULLABLE")
arcpy.AddField_management(BCAATableName, "GBA", "DOUBLE", "", "", "",
                          "", "NULLABLE")
arcpy.AddField_management(BCAATableName, "GLA", "DOUBLE", "", "", "",
                          "", "NULLABLE")
arcpy.AddField_management(BCAATableName, "NLA", "DOUBLE", "", "", "",
                          "", "NULLABLE")
arcpy.AddField_management(BCAATableName, "LandAssessment", "DOUBLE", "", "", "",
                          "", "NULLABLE")
arcpy.AddField_management(BCAATableName, "BuildingAssessment", "DOUBLE", "", "", "",
                          "", "NULLABLE")
arcpy.AddField_management(BCAATableName, "TotalAssessment", "DOUBLE", "", "", "",
                          "", "NULLABLE")
arcpy.AddField_management(BCAATableName, "TaNDM_Folio", "TEXT", "", "", 20)
arcpy.AddField_management(BCAATableName, "TaNDM_AUC", "TEXT", "", "", 3)
arcpy.AddField_management(BCAATableName, "TaNDM_MCC", "TEXT", "", "", 4)
arcpy.AddField_management(BCAATableName, "TaNDM_BuildingEra", "LONG", "", "", "",
                          "", "NULLABLE")
arcpy.AddField_management(BCAATableName, "TaNDM_NosUnits", "LONG", "", "", "",
                          "", "NULLABLE")
arcpy.AddField_management(BCAATableName, "TaNDM_FloorArea", "DOUBLE", "", "", "",
                          "", "NULLABLE")
arcpy.AddField_management(BCAATableName, "TaNDM_FloorAreaType", "TEXT", "", "", 50)


for line in fileinput.input(listOfBCAABIRTextFiles): # Open the input file
    textarray = line.split('|')
    
    cursorAdd = arcpy.InsertCursor(BCAATableName)
    row = cursorAdd.newRow()

    if len(textarray[0]) > 0:
        texttouse = textarray[0]
    else:
        texttouse = ""
    row.Area = texttouse
    
    if len(textarray[1]) > 0:
        texttouse = textarray[1]
    else:
        texttouse = ""
    row.Jur = texttouse
    
    if len(textarray[2]) > 0:
        texttouse = textarray[2]
    else:
        texttouse = ""
    row.Roll = texttouse
    
    if len(textarray[3]) > 0:
        texttouse = textarray[3]
    else:
        texttouse = ""
    row.CivicAddress = texttouse

    if len(textarray[4]) > 0:
        texttouse = textarray[4]
    else:
        texttouse = ""
    row.PID = texttouse

    if len(textarray[5]) > 0:
        texttouse = textarray[5]
    else:
        texttouse = ""
    row.LegalDesc = texttouse

    if len(textarray[6]) > 0:
        texttouse = textarray[6]
    else:
        texttouse = ""
    row.LotDimensions = texttouse
    
    if len(textarray[7]) > 0:
        texttouse = float(textarray[7])
    else:
        texttouse = 0
    row.LandSize = texttouse
    
    if len(textarray[8]) > 0:
        texttouse = float(textarray[8])
    else:
        texttouse = 0
    row.LandDepth = texttouse

    if len(textarray[9]) > 0:
        texttouse = textarray[9]
    else:
        texttouse = ""
    row.PrimAUC = texttouse

    if len(textarray[10]) > 0:
        texttouse = textarray[10]
    else:
        texttouse = ""
    row.BuildingType = texttouse

    if len(textarray[11]) > 0:
        texttouse = textarray[11]
    else:
        texttouse = ""
    row.MCC = texttouse

    if len(textarray[12]) > 0:
        texttouse = int(textarray[12])
    else:
        texttouse = 0
    row.YearBuilt = texttouse

    if len(textarray[13]) > 0:
        texttouse = int(textarray[13])
    else:
        texttouse = 0
    row.EffectiveYear = texttouse

    if len(textarray[14]) > 0:
        texttouse = float(textarray[14])
    else:
        texttouse = 0
    row.TotalArea = texttouse

    if len(textarray[15]) > 0:
        texttouse = float(textarray[15])
    else:
        texttouse = 0
    row.FoundationArea = texttouse

    if len(textarray[16]) > 0:
        texttouse = textarray[16]
    else:
        texttouse = ""
    row.Occupancy = texttouse

    if len(textarray[17]) > 0:
        texttouse = textarray[17]
    else:
        texttouse = ""
    row.UnitOfMeasure = texttouse

    if len(textarray[18]) > 0:
        texttouse = float(textarray[18])
    else:
        texttouse = 1
    row.NosUnits = texttouse

    if len(textarray[19]) > 0:
        texttouse = float(textarray[19])
    else:
        texttouse = 0
    row.StrataUnitArea = texttouse

    if len(textarray[20]) > 0:
        texttouse = float(textarray[20])
    else:
        texttouse = 0
    row.GBA = texttouse

    if len(textarray[21]) > 0:
        texttouse = float(textarray[21])
    else:
        texttouse = 0
    row.GLA = texttouse

    if len(textarray[22]) > 0:
        texttouse = float(textarray[22])
    else:
        texttouse = 0
    row.NLA = texttouse

    if len(textarray[23]) > 0:
        texttouse = float(textarray[23])
    else:
        texttouse = 0
    row.LandAssessment = texttouse

    if len(textarray[24]) > 0:
        texttouse = float(textarray[24])
    else:
        texttouse = 0
    row.BuildingAssessment = texttouse

    if len(textarray[25]) > 0:
        texttouse = float(textarray[25])
    else:
        texttouse = 0
    row.TotalAssessment = texttouse

    cursorAdd.insertRow(row)
    del row 
    del cursorAdd
fileinput.close()

arcpy.AddMessage("Added ROWS ...")

# Set the parameters to calculate fields in the BCAA table
arcpy.MakeTableView_management(BCAATableName,"BCAATableView")
targetTable = "BCAATableView"
defaultNumberValue = "0"
defaultTextValue = "'na'"

# Calculate fields the parcel GIS layer
targetFieldName = "TaNDM_Folio"
arcpy.CalculateField_management(targetTable, targetFieldName, defaultTextValue, "PYTHON")
arcpy.CalculateField_management(targetTable, targetFieldName, "!Jur! + !Roll!", "PYTHON", "")
arcpy.AddMessage("1")

targetFieldName = "TaNDM_AUC"
arcpy.CalculateField_management(targetTable, targetFieldName, defaultTextValue, "PYTHON")
arcpy.CalculateField_management(targetTable, targetFieldName, "!PrimAUC!", "PYTHON", "")
arcpy.AddMessage("2")

targetFieldName = "TaNDM_MCC"
arcpy.CalculateField_management(targetTable, targetFieldName, defaultTextValue, "PYTHON")
arcpy.CalculateField_management(targetTable, targetFieldName, "!MCC!", "PYTHON", "")
arcpy.AddMessage("3")

targetFieldName = "TaNDM_NosUnits"
arcpy.CalculateField_management(targetTable, targetFieldName, defaultNumberValue, "PYTHON")
arcpy.CalculateField_management(targetTable, targetFieldName, "!NosUnits!", "PYTHON", "")
arcpy.AddMessage("3")

#Do we add Foundation Area as well?
targetFieldName = "TaNDM_FloorArea"
arcpy.CalculateField_management(targetTable, targetFieldName, defaultNumberValue, "PYTHON")

arcpy.SelectLayerByAttribute_management("BCAATableView", "NEW_SELECTION", "\"TotalArea\" >0")
arcpy.CalculateField_management("BCAATableView", targetFieldName, "!TotalArea!", "PYTHON", "")
arcpy.CalculateField_management("BCAATableView", "TaNDM_FloorAreaType", "'TotalArea'", "PYTHON", "")
arcpy.SelectLayerByAttribute_management("BCAATableView", "NEW_SELECTION", "\"StrataUnitArea\" >0 and \"TaNDM_FloorArea\" =0")
arcpy.CalculateField_management("BCAATableView", targetFieldName, "!StrataUnitArea!", "PYTHON", "")
arcpy.CalculateField_management("BCAATableView", "TaNDM_FloorAreaType", "'StrataUnitArea'", "PYTHON", "")
arcpy.SelectLayerByAttribute_management("BCAATableView", "NEW_SELECTION", "\"GBA\" >0 and \"TaNDM_FloorArea\" =0")
arcpy.CalculateField_management("BCAATableView", targetFieldName, "!GBA!", "PYTHON", "")
arcpy.CalculateField_management("BCAATableView", "TaNDM_FloorAreaType", "'GBA'", "PYTHON", "")
arcpy.SelectLayerByAttribute_management("BCAATableView", "NEW_SELECTION", "\"GLA\" >0 and \"TaNDM_FloorArea\" =0")
arcpy.CalculateField_management("BCAATableView", targetFieldName, "!GLA!", "PYTHON", "")
arcpy.CalculateField_management("BCAATableView", "TaNDM_FloorAreaType", "'GLA'", "PYTHON", "")
arcpy.SelectLayerByAttribute_management("BCAATableView", "NEW_SELECTION", "\"NLA\" >0 and \"TaNDM_FloorArea\" =0")
arcpy.CalculateField_management("BCAATableView", targetFieldName, "!NLA!", "PYTHON", "")
arcpy.CalculateField_management("BCAATableView", "TaNDM_FloorAreaType", "'NLA'", "PYTHON", "")

# Process: Select Layer By Attribute
# Added GBA > 0 to handle folio combinations with other types of area such as Total Area
arcpy.SelectLayerByAttribute_management("BCAATableView", "NEW_SELECTION", "\"OCCUPANCY\" NOT LIKE '%PARKING%' and \"GBA\" >0")

# Process: Frequency
arcpy.Frequency_analysis("BCAATableView", GBAAreaFrequencyTableName, "GBA;TaNDM_Folio", "NosUnits")

arcpy.MakeTableView_management(GBAAreaFrequencyTableName, "GBAAreaFrequencyView")
                                        
arcpy.SelectLayerByAttribute_management("GBAAreaFrequencyView", "NEW_SELECTION", "\"FREQUENCY\" < 2")
if arcpy.GetCount_management("GBAAreaFrequencyView") > 0:
       arcpy.DeleteRows_management("GBAAreaFrequencyView")                                       

arcpy.SelectLayerByAttribute_management("GBAAreaFrequencyView", "NEW_SELECTION", "\"NosUnits\" >1000")
if arcpy.GetCount_management("GBAAreaFrequencyView") > 0:
       arcpy.DeleteRows_management("GBAAreaFrequencyView")

# Set the parameters to add fields to the GBAArea frequency table
targetTable = GBAAreaFrequencyTableName
defaultNumberValue = "0"

# Add fields to link frequency table with the BCA table
targetFieldName = "IndividualUnitArea"
arcpy.AddField_management(targetTable, targetFieldName, "DOUBLE", "", "", "", "", "NULLABLE")
arcpy.CalculateField_management(targetTable, targetFieldName, defaultNumberValue, "PYTHON")
arcpy.CalculateField_management(targetTable, targetFieldName, "!GBA! / !NosUnits!", "PYTHON", "")
arcpy.AddMessage("Calculated individual area for units")

targetFieldName = "GBA_As_Text"
arcpy.AddField_management(targetTable, targetFieldName, "TEXT", "", "", 55)
arcpy.CalculateField_management(targetTable, targetFieldName, "!GBA!", "PYTHON", "")

targetFieldName = "IndividualUnitArea_Link"
arcpy.AddField_management(targetTable, targetFieldName, "TEXT", "", "", 55)
arcpy.CalculateField_management(targetTable, targetFieldName, "!TaNDM_Folio! + '-' + !GBA_As_Text!", "PYTHON", "")

targetTable = "BCAATableView"
targetFieldName = "GBA_As_Text"
arcpy.AddField_management(targetTable, targetFieldName, "TEXT", "", "", 55)
arcpy.CalculateField_management(targetTable, targetFieldName, "!GBA!", "PYTHON", "")

targetFieldName = "IndividualUnitArea_Link"
arcpy.AddField_management(targetTable, targetFieldName, "TEXT", "", "", 55)
arcpy.CalculateField_management(targetTable, targetFieldName, "!TaNDM_Folio! + '-' + !GBA_As_Text!", "PYTHON", "")

arcpy.AddMessage("Calculated individual area for units")

arcpy.JoinField_management("BCAATableView", "IndividualUnitArea_Link", GBAAreaFrequencyTableName, "IndividualUnitArea_Link", ["IndividualUnitArea"])
# Added GBA > 0 to handle folio combinations with other types of area such as Total Area or NLA
arcpy.SelectLayerByAttribute_management("BCAATableView", "NEW_SELECTION", "\"IndividualUnitArea\" >0 and \"GBA\" >0")
arcpy.CalculateField_management("BCAATableView", "TaNDM_FloorArea", "!NosUnits! * !IndividualUnitArea! ", "PYTHON", "")

arcpy.AddMessage("Completed calculations for GBA areas that occur over more than one record...")



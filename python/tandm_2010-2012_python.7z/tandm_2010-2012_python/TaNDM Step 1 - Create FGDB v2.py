#Script written by Brett Korteling of Vive le Monde Mapping - brett@vivelemonde.net (Jan 2012)

# Create a working FGDB, import needed spatial layers and tables
# guided by selections in the tools GUI, add TaNDM specific fields and calculate accross values
# replace NULL values with dummy values of 'Unassigned' for text and '0' for numbers where possible
#
# Spatial layers needed for this to work: Parcel, Assessment fabric, Planning neighbourhoods, Census neighbourhoods
# if there is only one of either a planning or census neighbourhood layer, add whichever one is available twice and delete all reference to it's wrong assigment after all the scripts are completed
# or leave it in, there is no harm having the planning and census neighbourhoods holding the same information
#
# Tabular data needed for this to work: Actual Use and Manual Class Code lookup tables (both created by the TaNDM working group) and
# BC Assessment Residential and Commercial Inventories
# if there is only one of a residential or commercial inventory, add whichever one is available twice and delete all reference to it's wrong assigment after all the scripts are completed
# or leave it in, there is no harm having the planning and census neighbourhoods holding the same information
#
# A projection file is needed so that all layers can be stored in the same coordinate system
#
# Please see comments in the block of script that grabs parameters to see what format fields are required in
# Required fields are PID, JUROL, Acutual Use Code
# Non-essential fields are Manual Class Code and Floor Area
# if for some reason you have a spatial layer or data table that is missing one of the non-essential fields,
# then add one and fill it with dummy values before starting the script

import arcpy
from arcpy import env

# Grab parameters from the tool GUI
inFGDBName   = arcpy.GetParameterAsText(0)
inWorkspaceFolder  = arcpy.GetParameterAsText(1)
inParcelLayer  = arcpy.GetParameterAsText(2)
inPlanningNeighbourhoodLayer  = arcpy.GetParameterAsText(3)
inPlanningNeighbourhoodField  = arcpy.GetParameterAsText(4)
inCensusNeighbourhoodLayer  = arcpy.GetParameterAsText(5)
inCensusNeighbourhoodField  = arcpy.GetParameterAsText(6)
inAssessmentFabricLayer  = arcpy.GetParameterAsText(7)
inFolioField  = arcpy.GetParameterAsText(8)
inActualUseCodeTable  = arcpy.GetParameterAsText(9)
inManualClassCodeTable  = arcpy.GetParameterAsText(10)
inOccupancyTable  = arcpy.GetParameterAsText(11)
inUnitOfMeasureTable  = arcpy.GetParameterAsText(12)
inProjectionFile = arcpy.GetParameterAsText(13)

# Process: Create File FGDB
theGeodatabase = inWorkspaceFolder + "\\" + inFGDBName + ".gdb"

if arcpy.Exists(theGeodatabase):
    arcpy.Delete_management(theGeodatabase, "Workspace")
arcpy.CreateFileGDB_management(inWorkspaceFolder, inFGDBName, "10.0")

WorkingDirectory = inWorkspaceFolder + "\\" + inFGDBName + ".gdb"
arcpy.env.workspace = inWorkspaceFolder + "\\" + inFGDBName + ".gdb"
arcpy.env.outputCoordinateSystem = inProjectionFile


# Process: add spatial layers to the working FGDB
ParcelFullName = WorkingDirectory + "\\Parcel"
if arcpy.Exists(ParcelFullName):
    arcpy.Delete_management(ParcelFullName, "Feature Class")
arcpy.FeatureClassToFeatureClass_conversion(inParcelLayer, theGeodatabase, "Parcel", "")

AssessmentFabricFullName = WorkingDirectory + "\\BCAssessment"
if arcpy.Exists(AssessmentFabricFullName):
    arcpy.Delete_management(AssessmentFabricFullName, "Feature Class")
arcpy.FeatureClassToFeatureClass_conversion(inAssessmentFabricLayer, theGeodatabase, "BCAssessment", "")

PlanningNeighbourhoodFullName = WorkingDirectory + "\\PlanningNeighbourhood"
if arcpy.Exists(PlanningNeighbourhoodFullName):
    arcpy.Delete_management(PlanningNeighbourhoodFullName, "Feature Class")
arcpy.FeatureClassToFeatureClass_conversion(inPlanningNeighbourhoodLayer, theGeodatabase, "PlanningNeighbourhood", "")
    
CensusNeighbourhoodFullName = WorkingDirectory + "\\CensusNeighbourhood"
if arcpy.Exists(CensusNeighbourhoodFullName):
    arcpy.Delete_management(CensusNeighbourhoodFullName, "Feature Class")
arcpy.FeatureClassToFeatureClass_conversion(inCensusNeighbourhoodLayer, theGeodatabase, "CensusNeighbourhood", "")

arcpy.AddMessage("Transfered all spatial layers to " + WorkingDirectory + " ...")

# Process: add tabular data to the working FGDB
thelutActualUseCodeTable = WorkingDirectory + "\\lutActualUseCodeTable"
if arcpy.Exists(thelutActualUseCodeTable):
    arcpy.Delete_management(thelutActualUseCodeTable, "Table")
arcpy.TableToTable_conversion(inActualUseCodeTable, theGeodatabase, "lutActualUseCodeTable", "","")
    
thelutManualClassCodeTable = WorkingDirectory + "\\lutManualClassCodeTable"
if arcpy.Exists(thelutManualClassCodeTable):
    arcpy.Delete_management(thelutManualClassCodeTable, "Table")
arcpy.TableToTable_conversion(inManualClassCodeTable, theGeodatabase, "lutManualClassCodeTable", "","")

thelutOccupancyTable = WorkingDirectory + "\\lutOccupancyTable"
if arcpy.Exists(thelutOccupancyTable):
    arcpy.Delete_management(thelutOccupancyTable, "Table")
arcpy.TableToTable_conversion(inOccupancyTable, theGeodatabase, "lutOccupancyTable", "","")

thelutUnitOfMeasureTable = WorkingDirectory + "\\lutUnitOfMeasureTable"
if arcpy.Exists(thelutUnitOfMeasureTable):
    arcpy.Delete_management(thelutUnitOfMeasureTable, "Table")
arcpy.TableToTable_conversion(inUnitOfMeasureTable, theGeodatabase, "lutUnitOfMeasureTable", "","")

arcpy.AddMessage("Transfered all tabular data to " + WorkingDirectory + " ...")

# Make features layers and table views to accommodate python commands that manipulate tables
arcpy.MakeFeatureLayer_management(ParcelFullName,"ParcelView")
arcpy.MakeFeatureLayer_management(AssessmentFabricFullName,"AssessmentFabricView")
arcpy.MakeFeatureLayer_management(PlanningNeighbourhoodFullName,"PlanningNeighbourhoodView")
arcpy.MakeFeatureLayer_management(CensusNeighbourhoodFullName,"CensusNeighbourhoodView")


# Add TaNDM specific fields and calculate dummy values to get rid of NULL values where possible
targetFeatureClass = "ParcelView"
defaultNumberValue = "0"
defaultTextValue = "'Unassigned'"

targetFieldName = "TaNDM_Unique"
arcpy.AddField_management(targetFeatureClass, targetFieldName, "TEXT")
arcpy.SelectLayerByAttribute_management(targetFeatureClass, "CLEAR_SELECTION", "")
arcpy.CalculateField_management(targetFeatureClass, targetFieldName, "!OBJECTID!", "PYTHON")

targetFeatureClass = "AssessmentFabricView"
targetFieldName = "TaNDM_Folio"
arcpy.AddField_management(targetFeatureClass, targetFieldName, "TEXT")
arcpy.SelectLayerByAttribute_management(targetFeatureClass, "NEW_SELECTION", inFolioField + " = ''")
arcpy.CalculateField_management(targetFeatureClass, inFolioField, defaultTextValue, "PYTHON")
arcpy.SelectLayerByAttribute_management(targetFeatureClass, "CLEAR_SELECTION", "")
arcpy.CalculateField_management(targetFeatureClass, targetFieldName, "!" + inFolioField +"!", "PYTHON")

targetFeatureClass = "PlanningNeighbourhoodView"
targetFieldName = "TaNDM_PlanningNeighbourhood"
arcpy.AddField_management(targetFeatureClass, targetFieldName, "TEXT")
arcpy.SelectLayerByAttribute_management(targetFeatureClass, "NEW_SELECTION", inPlanningNeighbourhoodField + " = ''")
arcpy.CalculateField_management(targetFeatureClass, inPlanningNeighbourhoodField, defaultTextValue, "PYTHON")
arcpy.SelectLayerByAttribute_management(targetFeatureClass, "CLEAR_SELECTION", "")
arcpy.CalculateField_management(targetFeatureClass, targetFieldName, "!" + inPlanningNeighbourhoodField +"!", "PYTHON")

targetFeatureClass = "CensusNeighbourhoodView"
targetFieldName = "TaNDM_CensusNeighbourhood"
arcpy.AddField_management(targetFeatureClass, targetFieldName, "TEXT")
arcpy.SelectLayerByAttribute_management(targetFeatureClass, "NEW_SELECTION", inCensusNeighbourhoodField + " = ''")
arcpy.CalculateField_management(targetFeatureClass, inCensusNeighbourhoodField, defaultTextValue, "PYTHON")
arcpy.SelectLayerByAttribute_management(targetFeatureClass, "CLEAR_SELECTION", "")
arcpy.CalculateField_management(targetFeatureClass, targetFieldName, "!" + inCensusNeighbourhoodField +"!", "PYTHON")

arcpy.AddMessage("Added TaNDM standardized fields and calculated 'Unassigned' or '0' for all null values for spatial layers...")

targetFeatureClass = "AssessmentFabricView"
arcpy.SelectLayerByAttribute_management(targetFeatureClass, "NEW_SELECTION", "TaNDM_Folio = 'Unassigned'")
ReportOfSelection = str(arcpy.GetCount_management(targetFeatureClass))
arcpy.AddMessage(ReportOfSelection + " Assessment parcels without Folios, assigning temporary TaNDM Folios now...")

# Assign generic TaNDM-F... values to parcels that are missing a Folio
# This process allows for the creation of a spatial relationship with PIDs from the cadastral fabric when the parcel has no Folio

rows = arcpy.UpdateCursor("AssessmentFabricView", "TaNDM_Folio = 'Unassigned'","","TaNDM_Folio","TaNDM_Folio")
increment = 1
for row in rows:
    StringIncrement = str(increment)
    row.TaNDM_Folio = "TaNDM" + "-F" + StringIncrement
    increment = increment+1
    rows.updateRow(row)

# Assign generic TaNDM Planning -... values to planning neighbourhoods that are missing a name
# This process allows for the creation of a spatial relationship when neighbourhoods are not named

targetFeatureClass = "PlanningNeighbourhoodView"
arcpy.SelectLayerByAttribute_management(targetFeatureClass, "NEW_SELECTION", "TaNDM_PlanningNeighbourhood = 'Unassigned'")
ReportOfSelection = str(arcpy.GetCount_management(targetFeatureClass))
arcpy.AddMessage(ReportOfSelection + " Planning neighbourhoods without names, assigning temporary TaNDM names now...")

rows = arcpy.UpdateCursor("PlanningNeighbourhoodView", "TaNDM_PlanningNeighbourhood = 'Unassigned'","","TaNDM_PlanningNeighbourhood","TaNDM_PlanningNeighbourhood")
increment = 1
for row in rows:
    StringIncrement = str(increment)
    row.TaNDM_PlanningNeighbourhood = "TaNDM Planning " + "- " + StringIncrement
    increment = increment+1
    rows.updateRow(row)

# Assign generic TaNDM Census -... values to census neighbourhoods that are missing a name
# This process allows for the creation of a spatial relationship when census neighbourhoods are not named

targetFeatureClass = "CensusNeighbourhoodView"
arcpy.SelectLayerByAttribute_management(targetFeatureClass, "NEW_SELECTION", "TaNDM_CensusNeighbourhood = 'Unassigned'")
ReportOfSelection = str(arcpy.GetCount_management(targetFeatureClass))
arcpy.AddMessage(ReportOfSelection + " Census neighbourhoods without names, assigning temporary TaNDM names now...")

rows = arcpy.UpdateCursor("CensusNeighbourhoodView", "TaNDM_CensusNeighbourhood = 'Unassigned'","","TaNDM_CensusNeighbourhood","TaNDM_CensusNeighbourhood")
increment = 1
for row in rows:
    StringIncrement = str(increment)
    row.TaNDM_CensusNeighbourhood = "TaNDM Census " + "- " + StringIncrement
    increment = increment+1
    rows.updateRow(row)

arcpy.AddMessage("Completed assignment of TaNDM unique values to empty records in spatial layers...")

#Script written by Brett Korteling of Vive le Monde Mapping - brett@vivelemonde.net (Jan 2012)

# Export all relevant data layers from the preparation FGDB to an export Personal GDB and a FGDB copy as well

import arcpy
from arcpy import env

# Grab parameters from the tool GUI
inFGDBName   = arcpy.GetParameterAsText(0)
inPGDBName   = arcpy.GetParameterAsText(1)
inExportFolder  = arcpy.GetParameterAsText(2)

WorkingDirectory = inFGDBName
env.Workspace = WorkingDirectory

thePersonalGeodatabase = inExportFolder + "\\" + inPGDBName + ".mdb"
theFileGeodatabase = inExportFolder + "\\" + inPGDBName + ".gdb"

if arcpy.Exists(thePersonalGeodatabase):
    arcpy.Delete_management(thePersonalGeodatabase, "Workspace")
arcpy.CreatePersonalGDB_management(inExportFolder, inPGDBName, "10.0")

if arcpy.Exists(theFileGeodatabase):
    arcpy.Delete_management(theFileGeodatabase, "Workspace")
arcpy.CreateFileGDB_management(inExportFolder, inPGDBName, "10.0")


# Create names for input layers and remove previous occurrenced of output layers
BCABIRUniqueFullName = WorkingDirectory + "\\BCABIRUnique"
BCABIRFullReportFullName = WorkingDirectory + "\\BCABuildingInformationReport"
PIDFolioUniqueFullName = WorkingDirectory + "\\" + "PID_FolioUnique"
Summary_FoliosInAssessmentFabricAndNotFoundInBCATablesFullName = WorkingDirectory + "\\Summary_FoliosInAssessmentFabricAndNotFoundInBCATables"
Summary_FoliosInBCATablesAndNotFoundInAssessmentFabricFullName = WorkingDirectory + "\\Summary_FoliosInBCATablesAndNotFoundInAssessmentFabric"
Summary_FoliosSplitBetweenPIDsFullName = WorkingDirectory + "\\Summary_FolioSplitBetweenPIDs"

TaNDMParcelFullName = WorkingDirectory + "\\" + "TaNDM_Parcel"
AssessmentFabricFullName = WorkingDirectory + "\\" + "BCAssessment"
PlanningNeighbourhoodFullName = WorkingDirectory + "\\" + "PlanningNeighbourhood"
CensusNeighbourhoodFullName = WorkingDirectory + "\\" + "CensusNeighbourhood"

arcpy.MakeTableView_management(BCABIRUniqueFullName,"BCABIRUniqueView")
arcpy.MakeTableView_management(BCABIRFullReportFullName,"BCABuildingInformationReportView")
arcpy.MakeTableView_management(PIDFolioUniqueFullName,"PIDFolioUniqueView")
arcpy.MakeTableView_management(Summary_FoliosInAssessmentFabricAndNotFoundInBCATablesFullName,"Summary_FoliosInAssessmentFabricAndNotFoundInBCATablesView")
arcpy.MakeTableView_management(Summary_FoliosInBCATablesAndNotFoundInAssessmentFabricFullName,"Summary_FoliosInBCATablesAndNotFoundInAssessmentFabricView")
arcpy.MakeTableView_management(Summary_FoliosSplitBetweenPIDsFullName,"Summary_FolioSplitBetweenPIDsView")

arcpy.MakeFeatureLayer_management(TaNDMParcelFullName,"TaNDM_ParcelView")
arcpy.MakeFeatureLayer_management(AssessmentFabricFullName,"BCAssessmentView")
arcpy.MakeFeatureLayer_management(PlanningNeighbourhoodFullName,"PlanningNeighbourhoodView")
arcpy.MakeFeatureLayer_management(CensusNeighbourhoodFullName,"CensusNeighbourhoodView")

# Make sure all selections are clear to export the whole feature layer or table
arcpy.SelectLayerByAttribute_management("BCABIRUniqueView", "CLEAR_SELECTION", "")
arcpy.SelectLayerByAttribute_management("BCABuildingInformationReportView", "CLEAR_SELECTION", "")
arcpy.SelectLayerByAttribute_management("Summary_FoliosInAssessmentFabricAndNotFoundInBCATablesView", "CLEAR_SELECTION", "")
arcpy.SelectLayerByAttribute_management("Summary_FoliosInBCATablesAndNotFoundInAssessmentFabricView", "CLEAR_SELECTION", "")
arcpy.SelectLayerByAttribute_management("Summary_FolioSplitBetweenPIDsView", "CLEAR_SELECTION", "")

arcpy.SelectLayerByAttribute_management("TaNDM_ParcelView", "CLEAR_SELECTION", "")
arcpy.SelectLayerByAttribute_management("BCAssessmentView", "CLEAR_SELECTION", "")
arcpy.SelectLayerByAttribute_management("PlanningNeighbourhoodView", "CLEAR_SELECTION", "")
arcpy.SelectLayerByAttribute_management("CensusNeighbourhoodView", "CLEAR_SELECTION", "")

#Export all relevant data to the Personal Geodatabase
arcpy.TableToTable_conversion(BCABIRUniqueFullName, thePersonalGeodatabase, "TaNDM_BIR_Table", "", "")
arcpy.TableToTable_conversion(BCABIRFullReportFullName, thePersonalGeodatabase, "BCABuildingInformationReport", "", "")
arcpy.TableToTable_conversion(PIDFolioUniqueFullName, thePersonalGeodatabase, "TaNDM_PID_Folio_Many_to_Many", "", "")
arcpy.TableToTable_conversion(Summary_FoliosInAssessmentFabricAndNotFoundInBCATablesFullName, thePersonalGeodatabase, "TaNDM_Folios_in_AssessmentFabric_not_in_BCATables", "")
arcpy.TableToTable_conversion(Summary_FoliosInBCATablesAndNotFoundInAssessmentFabricFullName, thePersonalGeodatabase, "TaNDM_Folios_in_BCATables_not_in_AssessmentFabric", "")
arcpy.TableToTable_conversion(Summary_FoliosSplitBetweenPIDsFullName, thePersonalGeodatabase, "TaNDM_Folios_Split_OverMoreThanOne_Parcel", "", "")
arcpy.FeatureClassToFeatureClass_conversion (TaNDMParcelFullName, thePersonalGeodatabase, "TaNDM_Parcel", "", "", "")
arcpy.FeatureClassToFeatureClass_conversion (AssessmentFabricFullName, thePersonalGeodatabase, "AssessmentFabric", "", "", "")
arcpy.FeatureClassToFeatureClass_conversion (PlanningNeighbourhoodFullName, thePersonalGeodatabase, "TaNDM_PlanningNeighbourhood", "", "", "")
arcpy.FeatureClassToFeatureClass_conversion (CensusNeighbourhoodFullName, thePersonalGeodatabase, "TaNDM_CensusNeighbourhood", "", "", "")

arcpy.AddMessage("Created "+ thePersonalGeodatabase + " and tranferred data package files...")

#Export all relevant data to the File Geodatabase
arcpy.TableToTable_conversion(BCABIRUniqueFullName, theFileGeodatabase, "TaNDM_BIR_Table", "", "")
arcpy.TableToTable_conversion(BCABIRFullReportFullName, theFileGeodatabase, "BCABuildingInformationReport", "", "")
arcpy.TableToTable_conversion(PIDFolioUniqueFullName, theFileGeodatabase, "TaNDM_PID_Folio_Many_to_Many", "", "")
arcpy.TableToTable_conversion(Summary_FoliosInAssessmentFabricAndNotFoundInBCATablesFullName, theFileGeodatabase, "TaNDM_Folios_in_AssessmentFabric_not_in_BCATables", "")
arcpy.TableToTable_conversion(Summary_FoliosInBCATablesAndNotFoundInAssessmentFabricFullName, theFileGeodatabase, "TaNDM_Folios_in_BCATables_not_in_AssessmentFabric", "")
arcpy.TableToTable_conversion(Summary_FoliosSplitBetweenPIDsFullName, theFileGeodatabase, "TaNDM_Folios_Split_OverMoreThanOne_Parcel", "", "")
arcpy.FeatureClassToFeatureClass_conversion (TaNDMParcelFullName, theFileGeodatabase, "TaNDM_Parcel", "", "", "")
arcpy.FeatureClassToFeatureClass_conversion (AssessmentFabricFullName, theFileGeodatabase, "AssessmentFabric", "", "", "")
arcpy.FeatureClassToFeatureClass_conversion (PlanningNeighbourhoodFullName, theFileGeodatabase, "TaNDM_PlanningNeighbourhood", "", "", "")
arcpy.FeatureClassToFeatureClass_conversion (CensusNeighbourhoodFullName, theFileGeodatabase, "TaNDM_CensusNeighbourhood", "", "", "")

arcpy.AddMessage("Created "+ theFileGeodatabase + " and tranferred data package files...")
